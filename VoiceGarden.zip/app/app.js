'use strict';

// =================================================================================
// App Configuration
// =================================================================================

const {App} = require('jovo-framework');

const config = {
    logging: true,
};

const app = new App(config);


// =================================================================================
// App Logic
// =================================================================================

app.setHandler({
    'LAUNCH': function() {
        this.toIntent('HelloGardenIntent');
    },

    'HelloGardenIntent': function() {
        this.ask('Hi I\'m your personal gardener, what can I help you with?');
    },

    'MyFarmerNameIsIntent': function(name) {
        this.tell('Hey ' + name.value + ', nice to meet you!');
    },

    'EndSessionIntent': function() {
        this.tell('I\'ll be gardening, come back to see how it\'s going!');
    },

    'SoilMoistureIntent': function() {
        this.ask("Plant Soil Moisture endpoint working. any other tests?");
    },

    'RoomHumidityIntent': function() {
        this.ask("Room humidity endpoint working. any other tests?");
    },

    'RoomStatusIntent': function() {
        this.ask("Room status endpoint working. any other tests?");
    },

    'RoomTemperatureIntent': function() {
        this.ask("Room temperature endpoint working. any other tests?");
    },

    'WaterPlantIntent': function() {
        this.ask("Water plant endpoint working. any other tests?");
    },

});

module.exports.app = app;
